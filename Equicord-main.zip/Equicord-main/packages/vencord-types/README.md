# Vencord Types

Typings for Vencord's api, published to npm

```sh
npm i @vencord/types

yarn add @vencord/types

pnpm add @vencord/types
```
