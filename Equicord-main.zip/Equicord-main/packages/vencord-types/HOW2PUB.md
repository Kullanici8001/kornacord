# How to publish

1. run `pnpm generateTypes` in the project root
2. bump package.json version
3. npm publish
